# Sketch Puppet Module for Boxen

A Sketch app installer for Boxen

## Usage

```puppet
include sketch
```

## Required Puppet Modules

* `boxen`
