# Source Code Pro font module for Boxen

## Usage

```puppet
include font::source-code-pro
```

## Required Puppet Modules

None.
